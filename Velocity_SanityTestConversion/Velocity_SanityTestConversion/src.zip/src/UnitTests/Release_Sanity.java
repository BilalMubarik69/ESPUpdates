package UnitTests;

import java.io.File;
import java.util.NoSuchElementException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import TestData.Testdata;
import TestData.Testelements;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Release_Sanity {
	WebDriver driver;
	WebDriverWait wait;
	public static ExtentReports extent;
	public static ExtentTest test;
	
	@BeforeTest
	
	public void setup(){
		extent = new ExtentReports(System.getProperty("user.dir")+"/Reports/VelocityWithLicenceSupplier_2.24Release.html", true);
		extent.addSystemInfo("HostName", "Bilal")
		.addSystemInfo("Environment", "QA");
		extent.loadConfig(new File(System.getProperty("user.dir")+"/extent-config.xml"));
		
		System.setProperty("webdriver.chrome.driver",Testdata.sChromePath);
		driver=new ChromeDriver();
		
		driver.get(Testdata.VelocityURL);
		driver.manage().window().maximize();
		
		}
	
  @Test(priority=0)
  public void login() {
    try{
    	
    	
			 
	//Wait for the login buttons to be appear 
	
	wait = new WebDriverWait(driver, 120);
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.ASI_Num)));
    
    if(driver.getCurrentUrl().contains("stage")){
        //Insert ASI Number
        driver.findElement(By.cssSelector(Testelements.ASI_Num)).sendKeys(Testdata.vEASINumberStage);
        
        //Insert the username
        driver.findElement(By.cssSelector(Testelements.USername)).sendKeys(Testdata.vEUserNameStage);
        
        //Insert the Password
        driver.findElement(By.cssSelector(Testelements.Password)).sendKeys(Testdata.vEPasswordStage);
        }
        else if(driver.getCurrentUrl().contains("uat")){
        	
        	//Insert ASI Number
            driver.findElement(By.cssSelector(Testelements.ASI_Num)).sendKeys(Testdata.vEASINumberUAT);
            
            //Insert the username
            driver.findElement(By.cssSelector(Testelements.USername)).sendKeys(Testdata.vEUserNameUAT);
            
            //Insert the Password
            driver.findElement(By.cssSelector(Testelements.Password)).sendKeys(Testdata.vEPasswordUAT);	
        }
        
        else{
        	
        	//Insert ASI Number
            driver.findElement(By.cssSelector(Testelements.ASI_Num)).sendKeys(Testdata.vEASINumberProd);
            
            //Insert the username
            driver.findElement(By.cssSelector(Testelements.USername)).sendKeys(Testdata.vEUserNameProd);
            
            //Insert the Password
            driver.findElement(By.cssSelector(Testelements.Password)).sendKeys(Testdata.vEPasswordProd);	
        }
        
    //Press the login Button
    driver.findElement(By.cssSelector(Testelements.LoginButton)).click();
    
  
    test = extent.startTest("Login");
	Assert.assertFalse(false);
	test.log(LogStatus.PASS, "Login to Esp Updates Successfully");
    
	
    
    }    
    //Catch the exception if any
    catch(NoSuchElementException e){
    	e.getStackTrace();
    	test = extent.startTest("LoginFail");
		Assert.assertTrue(true);
		test.log(LogStatus.FAIL, "Condition is fail");
    
    }
  }  
   
  @Test(priority=1)
  public void SupplierSearch(){
	  try{
	  //Wait for supplier asi insertion field to appear
	  wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Supplier_asi_Insertion)));
      //Send info into asi field
      driver.findElement(By.cssSelector(Testelements.Supplier_asi_Insertion)).sendKeys("30232");
      //Click the search for supplier serach
      driver.findElement(By.cssSelector(Testelements.Supplier_asi_search)).click();
      //Wait for supplier selection option to appear
      wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Supplier_selection)));
      //Select the supplier through clicking
      driver.findElement(By.cssSelector(Testelements.Supplier_selection)).click();
      
      test = extent.startTest("SupplierSearch");
  	Assert.assertFalse(false);
  	test.log(LogStatus.PASS, "Supplier Searched Successfully");
	  
  	
	  
	  }catch(NoSuchElementException e){
	  e.getStackTrace();
	  test = extent.startTest("SupplierSearch");
	  Assert.assertTrue(true);
	  test.log(LogStatus.FAIL, "Condition is fail");
  }
  
  }



  @Test(priority=2)
  public void SKUField_BasicDetails_Displayed() throws InterruptedException{
  	try{
	  //Wait for supplier selection option to appear
      wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Manage_Tab_Action)));
	  
      Thread.sleep(3000);
	  
	  //Click the manage product tab
	  	driver.findElement(By.cssSelector(Testelements.Manage_Tab_Action)).click();
	      //Wait for the process to complete	    	
	  	wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.AddProductButton_EITSupplier)));
	      
	    Thread.sleep(3000);
	      //First store parent window to switch back
	    String parentWindow = driver.getWindowHandle();

	      
	      driver.findElement(By.cssSelector(Testelements.AddProductButton_EITSupplier)).click();

	    //Switch to new window opened
	  	for(String winHandle : driver.getWindowHandles()){
	  	    if(!winHandle.equals(parentWindow)) {
	  	        driver.switchTo().window(winHandle);
	  	    }
	  	}
	  	  
	  	
	  		Thread.sleep(3000);
	  	


	      //Insert the product name
	  	driver.findElement(By.cssSelector(Testelements.Product_Name)).sendKeys(Testdata.Productname);
	  	
	  	//Insert Product description
	  	driver.findElement(By.cssSelector(Testelements.Product_description)).sendKeys("Description: Our most popular bottle, available in a variety of colors to help brighten up anybodys gear. The large opening on our wide-mouth bottles easily accommodates ice cubes, fits most water purifiers and filters, and makes hand washing a breeze. The attached loop-top never gets lost and screws on and off easily. Printed graduations let keep track of your hydration. Dishwasher safe Please make sure the top does not touch the heating element, or it will melt.");

	     //Select the product type
	  	//driver.findElement(By.cssSelector(Testelements.Product_type)).click();
	  	
	  	 //Creating a robot instance to select option in 2nd place in dropdown
	  	WebElement mySelectElement20 = driver.findElement(By.xpath(Testelements.ProductType));
	      Select dropdown20= new Select(mySelectElement20);
	     
	      dropdown20.selectByVisibleText("Automotive Accessories");

	      //Press the apply button to add the product
	      driver.findElement(By.cssSelector(Testelements.AddProduct_Applybutton)).click();

	      wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Product_Basicdetails)));
	      
	      //Wait all tabs to be enabled
	      driver.findElement(By.cssSelector(Testelements.Product_Basicdetails)).isEnabled();
	      
	      
	      
	      //Switch back to parent window 
	      driver.switchTo().window(parentWindow);
	      
	      
	  		Thread.sleep(45000);
	  
	   
	  		if(driver.findElement(By.cssSelector(Testelements.SKUField_BasicDetails_Displayed)).isDisplayed()){
	  			
	  			System.out.print("SKU Field Displayed Sucessfully On Basic details screen,so verifaction of field displaying on basic details Passed");
	  			
	  			test = extent.startTest("SKUField_BasicDetails_Displayed");
	  		  	Assert.assertFalse(false);
	  		  	test.log(LogStatus.PASS, "SKU Field Displayed Sucessfully On Basic details screen,so verifaction of field displaying on basic details Passed");
	  		
	  		}
	  		else{
	  			
	  			System.out.print("SKU Field Displayed On Basic details screen Unsucessfull,so verifaction of field displaying on basic details Failed");
	  			test = extent.startTest("SKUField_BasicDetails_Displayed");
	  		    Assert.assertTrue(true);
	  		    test.log(LogStatus.FAIL, "SKU Field Displayed On Basic details screen Unsucessfull,so verifaction of field displaying on basic details Failed");
	  		
	  		}
	  		
	  	
  	      
  
  
  }
  	catch(NoSuchElementException e){
  	  e.getStackTrace();
  	}
  }

  @Test(priority=3)
public void ColorAttributes_AutoRename() throws InterruptedException{
	try{
	 //Insert the product number
    driver.findElement(By.cssSelector(Testelements.Product_Number)).sendKeys(Testdata.Productnumber);
    
  //Insert UPC code
    driver.findElement(By.cssSelector(Testelements.UPCCode)).sendKeys(Testdata.UPCCode);
    
  //Insert the product summary
    driver.findElement(By.cssSelector(Testelements.Product_Summary)).sendKeys("This is a velocity Test Product");
    
  
    
    
    
    //First store parent window to switch back
    String parentWindow1 = driver.getWindowHandle(); 
    
  
    
    
    //Open the category popup
    driver.findElement(By.cssSelector(Testelements.Productcategory_dropdown)).click();
    
  //Switch to new window opened
	for(String winHandle : driver.getWindowHandles()){
	    if(!winHandle.equals(parentWindow1)) {
	        driver.switchTo().window(winHandle);
	    }
	}
    
    
	Thread.sleep(3000);

  
 //Search the category
    driver.findElement(By.cssSelector(Testelements.Category_Searchfield)).sendKeys("Frames");
    
 
	Thread.sleep(2000);

    
    //Select 2  categories of frames 
    driver.findElement(By.cssSelector(Testelements.Product_category1)).click();
    
//Select the 2nd 1 
    driver.findElement(By.cssSelector(Testelements.Product_category2)).click();
    
//Press the apply on category product popup
    driver.findElement(By.cssSelector(Testelements.ProductCategory_ApplyButton)).click();
    
  //Switch back to parent window 
    driver.switchTo().window(parentWindow1);
   
    
    //Wait for 2 sec
    
		Thread.sleep(4000);
	
    //Select the pricing tab for SPG
  
    driver.findElement(By.cssSelector(Testelements.Product_attributes_Tab)).click();
  
   // Wait for attributes to appear
    
    wait = new WebDriverWait(driver, 180);
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Product_attributes_1)));
    
    
		Thread.sleep(2000);
	
    
    driver.findElement(By.cssSelector(Testelements.Product_attributes_1)).click();
    
    //Select the 2nd attribute
    driver.findElement(By.cssSelector(Testelements.Product_attributes_2)).click();

    Thread.sleep(10000);
    
    WebElement mySelectElement = driver.findElement(By.cssSelector(Testelements.WhiteHueColor_Dropdown));
    Select dropdown= new Select(mySelectElement);

    dropdown.selectByVisibleText("LIGHT");

    Thread.sleep(5000);

    if(driver.findElement(By.cssSelector(Testelements.LightWhiteTextColor_Verifiation)).getText().equals("Light White")){
    	
    	System.out.print("Attribute Hue color changes to Light White from Medium Sucessfully");
			
			test = extent.startTest("ColorAttributes_AutoRename_WhiteColor");
		  	Assert.assertFalse(false);
		  	test.log(LogStatus.PASS, "Attribute Hue color of White color changes to Light White from Medium Sucessfully");
   
    
    }
    else{
    	
    	System.out.print("Attribute Hue color changes to Light White from Medium Unsucessfull");
			test = extent.startTest("ColorAttributes_AutoRenam_WhiteColor");
		    Assert.assertTrue(true);
		    test.log(LogStatus.FAIL, "Attribute Hue color of White color changes to Light White from Medium Unsucessfull");
    }

    WebElement mySelectElement1 = driver.findElement(By.cssSelector(Testelements.BlueHueColor_Dropdown));
    Select dropdown1= new Select(mySelectElement1);

    dropdown1.selectByVisibleText("LIGHT");

    Thread.sleep(5000);

    if(driver.findElement(By.cssSelector(Testelements.LightBlueTextColor_Verification)).getText().equals("Light Blue")){
    	
    	System.out.print("Attribute Hue color changes to Light Blue from Medium Sucessfully");
			
			test = extent.startTest("ColorAttributes_AutoRename_BlueColor");
		  	Assert.assertFalse(false);
		  	test.log(LogStatus.PASS, "Attribute Hue color of blue color changes to Light Blue from Medium Sucessfully");
   
    
    }
    else{
    	
    	System.out.print("Attribute Hue color changes to Light Blue from Medium Unsucessfull");
			test = extent.startTest("ColorAttributes_AutoRenam_BlueColor");
		    Assert.assertTrue(true);
		    test.log(LogStatus.FAIL, "Attribute Hue color of Blue Color changes to Light Blue from Medium Unsucessfull");
    }

    Thread.sleep(3000);


}

catch(NoSuchElementException e){
	  e.getStackTrace();
	}
}
@Test(priority=4)
public void AddNewColors() throws InterruptedException{
	try{
	//Click the others color tab in attributes
	WebElement OthersTab=driver.findElement(By.cssSelector(Testelements.OtherColors_Tab_Atributes));
	
	OthersTab.click();
	
	Thread.sleep(3000);
	
	driver.findElement(By.cssSelector(Testelements.AnyOthersAll_Option_Newcolor)).click();
	
	Thread.sleep(4000);
	
	driver.findElement(By.cssSelector(Testelements.AnyAllColors_Popup)).click();
	
	Thread.sleep(4000);
	
	//Slect the color
	driver.findElement(By.cssSelector(Testelements.AnyAllColors_Selection)).click();
	Thread.sleep(3000);
	
	//Press the Apply button
	driver.findElement(By.cssSelector(Testelements.ApplySelection)).click();
	
	Thread.sleep(4000);
	
	//Click again others tab in attributes
	OthersTab.click();
	
    Thread.sleep(3000);
	
	driver.findElement(By.cssSelector(Testelements.Custom_NewColor)).click();
	
	Thread.sleep(4000);
	
     driver.findElement(By.cssSelector(Testelements.CustomNewColor_Popup)).click();
	
	Thread.sleep(4000);
	
	//Slect the color
	driver.findElement(By.cssSelector(Testelements.CustomNewColor_Selection)).click();
	Thread.sleep(3000);
	
	//Press the Apply button
	driver.findElement(By.cssSelector(Testelements.ApplySelection)).click();
	
	Thread.sleep(4000);
	
	
	
	//Click again others tab in attributes
		OthersTab.click();
		
	    Thread.sleep(3000);
		
		driver.findElement(By.cssSelector(Testelements.Standard_NewColor)).click();
	
		Thread.sleep(4000);

		 driver.findElement(By.cssSelector(Testelements.Standard_Newcolor_Popup)).click();
			
			Thread.sleep(4000);
			
			//Slect the color
			driver.findElement(By.cssSelector(Testelements.Standard_Newcolor_Selection)).click();
			Thread.sleep(3000);
			
			//Press the Apply button
			driver.findElement(By.cssSelector(Testelements.ApplySelection)).click();
			
			Thread.sleep(4000);
		
		//Click again others tab in attributes
		
			 //Scroll Up
		    JavascriptExecutor jse = (JavascriptExecutor)driver;
		    jse.executeScript("window.scrollBy(0,-250)", "");
		    
		    Thread.sleep(3000);
			
		OthersTab.click();
		
	    Thread.sleep(3000);
		
	    driver.findElement(By.cssSelector(Testelements.Other_Newcolor)).click();
	    
	    Thread.sleep(4000);
	    
	    driver.findElement(By.cssSelector(Testelements.Other_NewColorPopUp)).click();
		
		Thread.sleep(4000);
		
		//Slect the color
		driver.findElement(By.cssSelector(Testelements.Other_NewColorSelection)).click();
		Thread.sleep(3000);
		
		//Press the Apply button
		driver.findElement(By.cssSelector(Testelements.ApplySelection)).click();
		
		Thread.sleep(4000);
	    
		
	    test = extent.startTest("AddNewColors");
	  	Assert.assertFalse(false);
	  	test.log(LogStatus.PASS, "Add New Color Choices Sucessfully");


}

catch(NoSuchElementException e){
	  e.getStackTrace();
	}
}

@Test(priority=5)
public void NewProductsAddedByEIT_Unconfirmed() throws InterruptedException{
	try{
	//Goto imprinting tab and select imprinting
    driver.findElement(By.xpath(Testelements.ImprintingTab)).click();
    
    Thread.sleep(18000);
    
  //Scroll Up
    JavascriptExecutor jse1 = (JavascriptExecutor)driver;
    jse1.executeScript("window.scrollBy(0,-250)", "");
    
  //Scroll Up
    JavascriptExecutor jse2 = (JavascriptExecutor)driver;
    jse2.executeScript("window.scrollBy(-250,-500)", "");
    
    Thread.sleep(3000);
    
    //Select an option
    
    WebElement mySelectElement70 = driver.findElement(By.xpath(Testelements.ImprintingMethodSelection));
    Select dropdown70= new Select(mySelectElement70);
   
    dropdown70.selectByVisibleText("Silkscreen");
    
    Thread.sleep(3000);
    
    WebElement element = driver.findElement(By.xpath(Testelements.ImprintingMethodSelectionAdd));
    JavascriptExecutor executor = (JavascriptExecutor)driver;
    executor.executeScript("arguments[0].click();", element);
   
    Thread.sleep(12000);
    
    
    
    
    //Open the pricing tab
    driver.findElement(By.cssSelector(Testelements.product_pricingtab)).click();
    
    //Wait for all the fields to be appeared
    wait = new WebDriverWait(driver, 180);
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.SPG_Quantity_1)));
    
		Thread.sleep(2000);
	
    
    //Insert the details
    driver.findElement(By.cssSelector(Testelements.SPG_Quantity_1)).sendKeys("1");
    
    driver.findElement(By.cssSelector(Testelements.SPG_Listprice_1)).sendKeys("20");
    
    //driver.findElement(By.cssSelector(Testelements.SPG_Pricecode_1)).click();
    
    WebElement mySelectElement100 = driver.findElement(By.xpath(Testelements.PriceCode1));
    Select dropdown100= new Select(mySelectElement100);
   
    dropdown100.selectByVisibleText("L 70%");
    
  
		
	driver.findElement(By.cssSelector(Testelements.SPG_Quantity_2)).sendKeys("2");
	
	driver.findElement(By.cssSelector(Testelements.SPG_Listprice2)).sendKeys("10");
	
	//driver.findElement(By.cssSelector(Testelements.SPG_Pricecode_2)).click();
	//Selection from through robots   
	
	
	 WebElement mySelectElement71 = driver.findElement(By.xpath(Testelements.PriceCode2));
        Select dropdown71= new Select(mySelectElement71);
       
        dropdown71.selectByVisibleText("L 70%");
	
	if(driver.findElement(By.cssSelector(Testelements.PriceConfirmedCheckbox_Pricing)).isSelected()){
		
		System.out.print("New Product Pricing Confirmed check box on pricing screen is checked");
		test = extent.startTest("NewProductsAddedByEIT_Unconfirmed");
	    Assert.assertTrue(true);
	    test.log(LogStatus.FAIL, "New Product Pricing Confirmed check box on pricing screen is checked,So Case Failed");
		
	}
	else{
		
		System.out.print("New Product Pricing Confirmed check box on pricing screen is unchecked");
		
		test = extent.startTest("NewProductsAddedByEIT_Unconfirmed");
	  	Assert.assertFalse(false);
	  	test.log(LogStatus.PASS, "New Product Pricing Confirmed check box on pricing screen is unchecked,So Case Passed Sucessfully");

	}
	
   Thread.sleep(3000);
}

catch(NoSuchElementException e){
	  e.getStackTrace();
	}
}
@Test(priority=6)
public void Availability_CheckUncheckAll_Verification() throws InterruptedException{
	try{
	//Move to Images tab
  	driver.findElement(By.cssSelector(Testelements.Product_Image_Tab)).click();
  	
   //Wait for the button to appear
  	 wait = new WebDriverWait(driver, 180);
       wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Product_Images_MediaLibrary_Button)));
          
       
       
       //First store parent window to switch back
       String parentWindow2 = driver.getWindowHandle(); 
       
       //Press the medialibrary button select image
       driver.findElement(By.cssSelector(Testelements.Product_Images_MediaLibrary_Button)).click();
       
     //Switch to new window opened
      	for(String winHandle : driver.getWindowHandles()){
      	    if(!winHandle.equals(parentWindow2)) {
      	        driver.switchTo().window(winHandle);
      	    }
      	}
          
          
  		Thread.sleep(7000);
  	
       
    //Select the images to upload
       driver.findElement(By.cssSelector(Testelements.MediaLibrary_Image1)).click();
       
       JavascriptExecutor jse89 = (JavascriptExecutor)driver;
       jse89.executeScript("window.scrollBy(0,250)", "");
	   	
       
		Thread.sleep(3000);
	
       
        
       
  
  	Thread.sleep(5000);
 
       
       //Confirm the images uploading details
       driver.findElement(By.cssSelector(Testelements.MediaLibrary_Popup_Confirmbutton)).click();
       
   
       //Switch back to parent window 
          driver.switchTo().window(parentWindow2);
          
     
  	Thread.sleep(5000);
  
          
         
   //Tagging the colors to image in creteria section
     Actions act=new Actions(driver);
     //1st Color(White) tagging  
    // find element which we need to drag
    WebElement drag=driver.findElement(By.xpath("html/body/div[2]/div/section/section[4]/div[2]/div[1]/div[2]/div[2]/ul/li/ul/li[1]/span"));
     
    
    
    
    
    // find element which we need to drop
    WebElement drop=driver.findElement(By.xpath("html/body/div[2]/div/section/section[4]/div[2]/div[2]/div/div[2]/div/ul/li/div[2]/ul"));
     
    // this will drag element to destination
    act.dragAndDrop(drag, drop).build().perform();
     
    
  	Thread.sleep(10000);
  
    
    
    //2nd Colors(Blue) Tag 
    Actions act1=new Actions(driver);
      
    // find element which we need to drag
    WebElement drag1=driver.findElement(By.xpath("html/body/div[2]/div/section/section[4]/div[2]/div[1]/div[2]/div[2]/ul/li/ul/li[2]/span"));
     
    
    
    
    
    // find element which we need to drop
    WebElement drop1=driver.findElement(By.xpath("html/body/div[2]/div/section/section[4]/div[2]/div[2]/div/div[2]/div/ul/li/div[2]/ul"));
     
    // this will drag element to destination
    act1.dragAndDrop(drag1, drop1).build().perform();   
       
    Thread.sleep(2000);
    
 driver.findElement(By.cssSelector(Testelements.SKUInventory)).click();
    
    
  	Thread.sleep(12000);
  
    driver.findElement(By.cssSelector(Testelements.SKUInventorySelection_dropdown)).click();
    
    driver.findElement(By.cssSelector(Testelements.SKUInventorySelection_dropdown)).sendKeys(Keys.DOWN);
    
    driver.findElement(By.cssSelector(Testelements.SKUInventorySelection_dropdown)).sendKeys(Keys.ENTER);
    
    
    
    
    
   
    
  	Thread.sleep(2000);
  
    driver.findElement(By.cssSelector(Testelements.SKUInventoryshow_button)).click();
    
    
  	Thread.sleep(4000);
 
    
    driver.findElement(By.xpath(Testelements.SKURequired1)).sendKeys("3");
    
    driver.findElement(By.xpath(Testelements.SKURequired2)).sendKeys("2");
    
    
    WebElement mySelectElement = driver.findElement(By.xpath(Testelements.Invstatus1));
    Select dropdown= new Select(mySelectElement);
   
    dropdown.selectByVisibleText("Always in stock");
    
    
    WebElement mySelectElement1 = driver.findElement(By.xpath(Testelements.Invstatus2));
    Select dropdown1= new Select(mySelectElement1);
    
    dropdown1.selectByVisibleText("Always in stock");
    
    
    
  	Thread.sleep(4000);
  
  	 driver.findElement(By.xpath(Testelements.SKUquantity1)).sendKeys("2");
  	 
  	 driver.findElement(By.xpath(Testelements.SKUquantity2)).sendKeys("3");
  	 
  	 
  	Thread.sleep(25000);
  

    	//Move to availability tab
     driver.findElement(By.xpath(Testelements.Availability_Tab)).click();
     
     
    Thread.sleep(13000);
    
      driver.findElement(By.xpath(Testelements.Availability_Firstvalue)).click();
      
      
      Thread.sleep(1000);
    	
      
      driver.findElement(By.xpath(Testelements.Availability_Firstvalue)).sendKeys(Keys.DOWN);
      
      
       Thread.sleep(1000);
    	
      
      driver.findElement(By.xpath(Testelements.Availability_Firstvalue)).sendKeys(Keys.ENTER);
      
      
      Thread.sleep(4000);
    	
     
     driver.findElement(By.xpath(Testelements.Availability_Secondvalue)).click();
     
     
    Thread.sleep(1000);
    	
     driver.findElement(By.xpath(Testelements.Availability_Secondvalue)).sendKeys(Keys.DOWN);
     
    
    Thread.sleep(1000);
    	
     
     driver.findElement(By.xpath(Testelements.Availability_Secondvalue)).sendKeys(Keys.DOWN);
     
     
     Thread.sleep(1000);
    	
     
     driver.findElement(By.xpath(Testelements.Availability_Secondvalue)).sendKeys(Keys.ENTER);
     
       	
     Thread.sleep(4000);
   
     driver.findElement(By.xpath(Testelements.Availability_showbutton)).click();	
       	
       	
     Thread.sleep(8000);
     
     //Scroll Up
	    JavascriptExecutor jse1 = (JavascriptExecutor)driver;
	    jse1.executeScript("window.scrollBy(0,-250)", "");
	    
	  //Scroll Up
	    JavascriptExecutor jse2 = (JavascriptExecutor)driver;
	    jse2.executeScript("window.scrollBy(-250,-500)", "");
	    
	    Thread.sleep(3000);
     
     //Unselect the slected avaialability
     driver.findElement(By.cssSelector(Testelements.Availability_Unselect)).click();
     
     Thread.sleep(8000);
     
     
     test = extent.startTest("Availability UnselectAll");
	  	Assert.assertFalse(false);
	  	test.log(LogStatus.PASS, "Unselect All Availability takes place sucessfully ");
	
 
	  	 //Unselect the slected avaialability
	     driver.findElement(By.cssSelector(Testelements.Availability_Select)).click();
	     
	     Thread.sleep(8000);
	     
	     
	     test = extent.startTest("Availability selectAll");
		  	Assert.assertFalse(false);
		  	test.log(LogStatus.PASS, "select All Availability takes place sucessfully ");
		
    
    //Go to basic details screen and verify is sku,inventory status and quantity field are enabled or not
		  	driver.findElement(By.cssSelector(Testelements.BasicDetails_Product)).click();
		  	
		  	Thread.sleep(15000);
		  	
		 //Now verify the fields now
		  	if(driver.findElement(By.cssSelector(Testelements.BasicDetails_SKUField)).isEnabled()){
		  		
		  		test = extent.startTest("Basic Details SKU Field Enabled Verification");
			  	Assert.assertFalse(false);
			  	test.log(LogStatus.PASS, "On Basic details screen SKU field is enabled");
		  		
		  	}
		  	else{
		  		
		  		test = extent.startTest("Basic Details SKU Field Enabled Verification");
			  	Assert.assertFalse(false);
			  	test.log(LogStatus.FAIL, "On Basic details screen SKU field is not enabled");
		  	}
		  	
		  	
            if(driver.findElement(By.cssSelector(Testelements.BasicDetails_InventoryStatus)).isEnabled()){
            	
            	test = extent.startTest("Basic Details Inventory Status Field Enabled Verification");
			  	Assert.assertFalse(false);
			  	test.log(LogStatus.PASS, "On Basic details screen Inventory Status field is enabled");
            }
		  		
            else{
            	
            	test = extent.startTest("Basic Details Inventory Status Field Enabled Verification");
			  	Assert.assertFalse(false);
			  	test.log(LogStatus.FAIL, "On Basic details screen Inventory Status field is not enabled");

            }
		  	
		  	Thread.sleep(3000);
		  	
		  	
		  	
		  	//Goto Summary Tab
      
		  	
		  	
		  	driver.findElement(By.cssSelector(Testelements.Product_Summary_Tab)).click();
          
     //Wait for some time
      
  		Thread.sleep(5000);
  

    driver.findElement(By.cssSelector(Testelements.Product_Manage)).click();
    
 
    
    
    
    
    
    //Wait for all the fields to be appeared
    wait = new WebDriverWait(driver, 180);
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Product_Active)));
    
    
    
  	Thread.sleep(4000);
  
    
    
    //Active the product
    driver.findElement(By.cssSelector(Testelements.Product_Active)).click();
    //Wait for the alert to appear
    wait = new WebDriverWait(driver, 180);
    wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Product_Active_Confirm)));
    //Press the ok button from alert
    driver.findElement(By.cssSelector(Testelements.Product_Active_Confirm)).click();
    
    
  	Thread.sleep(10000);
  
    
  
}
    
catch(NoSuchElementException e){
	  e.getStackTrace();
	}
}  
  
 @Test(priority=7)
 public void Product_InLegalReview() throws InterruptedException{
	 try{
	 //Select the product to sent it in legal review
	 driver.findElement(By.xpath(Testelements.BulkProduct_checkbox)).click();
	 
	 Thread.sleep(3000);
	 
	 //Click the bulk Edit Button
	 driver.findElement(By.xpath(Testelements.BulkEdit_Button)).click();
	 
	 Thread.sleep(4000);
	 
	 //Press the selected product radio button on bulk edit popup
	 driver.findElement(By.xpath(Testelements.BulkEdit_SelectProd)).click();
	 
	 Thread.sleep(2000);
	 
	 //Select the Set to review option in popup of bulk edit
	 driver.findElement(By.cssSelector(Testelements.SetToreview_Option)).click();
	 
	 Thread.sleep(3000);
	 
	 //Press the bulk edit button
	 driver.findElement(By.cssSelector(Testelements.BulkEdit_PopupButton)).click();
	 
	 Thread.sleep(7000);
	 
	 //Select the legal review checkbox
	 driver.findElement(By.cssSelector(Testelements.Legalreview_checkbox)).click();
	 
	 Thread.sleep(2000);
	 
	 //Enter the cooments for legal review section
	 driver.findElement(By.cssSelector(Testelements.Legalreview_Comments)).sendKeys("Set to Legal Review");
	 
	 Thread.sleep(3000);
	 
	
	 
	 
	 //Press the outer area to make the button enable for set to review
	 driver.findElement(By.cssSelector(Testelements.legalreview_Clickbalearea_ButtonEnable)).click();
	 
	 Thread.sleep(4000);
	 
	 //Press the set to review button for legal
	 driver.findElement(By.cssSelector(Testelements.SelectedProductInreview_Button)).click();
	 
	 Thread.sleep(6000);
	 
	 //Press the ok to confirm email
	 driver.findElement(By.cssSelector(Testelements.EmailNotificationalert_Confirm)).click();
	 
	 Thread.sleep(2000);
	 
	 driver.navigate().refresh();
	 
	 wait = new WebDriverWait(driver, 120);
	 wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.ProductLegalreviewText)));
	 
	 if(driver.findElement(By.cssSelector(Testelements.ProductLegalreviewText)).getText().equals("Your product is in review because of Legal Review")){
		 
	       System.out.print("Product becomes inactive sucessfully and changes to legal review");
	       test = extent.startTest("Product_InLegalReview");
		  	Assert.assertFalse(false);
		  	test.log(LogStatus.PASS, "Product becomes inactive sucessfully and changes to legal review");
	 
	 
	 }
	 else{
		 
		 System.out.print("Product becomes inactive unsucessfull and changes to legal review is also unsucessfull");
	       test = extent.startTest("Product_InLegalReview");
		  	Assert.assertFalse(false);
		  	test.log(LogStatus.FAIL, "Product becomes inactive unsucessfull and changes to legal review is also unsucessfull");
	 }
	 
     Thread.sleep(2000);
 
 }
  
 catch(NoSuchElementException e){
	  e.getStackTrace();
	} 
  
}
  
 @Test(priority=8)
 public void SupplierInReview_LegalReviewProduct_Download() throws InterruptedException{
	 try{
	 //Press the EIT Dashboard from action bar
	 driver.findElement(By.xpath(Testelements.EITDashboardButton)).click();
	 
	 //Wait for the EIt Reports tab to appear
	 //Wait for supplier selection option to appear
     wait = new WebDriverWait(driver, 180);
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITReports_Tab)));
     
     Thread.sleep(3000);
     
     //PRess the EIT Admin tab
     driver.findElement(By.xpath(Testelements.EITReports_Tab)).click();
     
     //Wait for supplier selection option to appear
     wait = new WebDriverWait(driver, 180);
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITReports_Selectreport_dropdown)));
     
     Thread.sleep(3000);
     
 	WebElement mySelectElement20 = driver.findElement(By.xpath(Testelements.EITReports_Selectreport_dropdown));
    Select dropdown20= new Select(mySelectElement20);
   
    dropdown20.selectByVisibleText("Products in review by supplier");
    
    Thread.sleep(3000);
    
    //Select the supplier checkbox
    driver.findElement(By.xpath(Testelements.EITReports_ProductsinReview3)).click();
    
    Thread.sleep(3000);
    
    driver.findElement(By.xpath(Testelements.LegalCheckbox_SupplierInreview)).click();
    
    Thread.sleep(5000);
    
    driver.findElement(By.xpath(Testelements.EITReports_Download3)).click();
    
    test = extent.startTest("SupplierInReview_LegalReviewProduct_Download");
  	Assert.assertFalse(false);
  	test.log(LogStatus.PASS, "Supplier Product with legal review downloaded sucessfully");
     
    
 }
 
 catch(NoSuchElementException e){
	  e.getStackTrace();
	} 
  
}
  
  @Test(priority=9)
  public void Product_WithRestrictedWords() throws InterruptedException{
	  
	  //Press the manage products tab on eit dashboard
	  driver.findElement(By.xpath(Testelements.EITManageProducts)).click();
	  
	//Wait for supplier asi insertion field to appear
	  wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Supplier_asi_Insertion)));
      //Send info into asi field
      driver.findElement(By.cssSelector(Testelements.Supplier_asi_Insertion)).sendKeys("30232");
      //Click the search for supplier serach
      driver.findElement(By.cssSelector(Testelements.Supplier_asi_search)).click();
      //Wait for supplier selection option to appear
      wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Supplier_selection)));
      //Select the supplier through clicking
      driver.findElement(By.cssSelector(Testelements.Supplier_selection)).click();
 
      //Wait for supplier selection option to appear
      wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.ManageProducts_Tab)));
      
      Thread.sleep(4000);
      
      //Click the manage products tab
      driver.findElement(By.xpath(Testelements.ManageProducts_Tab)).click();
      
      wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.MakeChangesActive)));

      Thread.sleep(3000);
      
      driver.findElement(By.cssSelector(Testelements.MakeChangesActive)).click();
      
      wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.MakeChangesActive_Confirm)));
      
      Thread.sleep(2000);
      
      //Press the ok button to active the product
      driver.findElement(By.cssSelector(Testelements.MakeChangesActive_Confirm)).click();
      
      Thread.sleep(10000);
      
      //Select the product to sent it in legal review
 	 driver.findElement(By.xpath(Testelements.BulkProduct_checkbox)).click();
 	 
 	 Thread.sleep(3000);
 	 
 	 //Click the bulk Edit Button
 	 driver.findElement(By.xpath(Testelements.BulkEdit_Button)).click();
 	 
 	 Thread.sleep(4000);
 	 
 	 //Press the selected product radio button on bulk edit popup
 	 driver.findElement(By.xpath(Testelements.BulkEdit_SelectProd)).click();
 	 
 	 Thread.sleep(2000);
 	 
 	 //Select the Set to review option in popup of bulk edit
 	 driver.findElement(By.cssSelector(Testelements.SetToreview_Option)).click();
 	 
 	 Thread.sleep(3000);
 	 
 	 //Press the bulk edit button
 	 driver.findElement(By.cssSelector(Testelements.BulkEdit_PopupButton)).click();
 	 
 	 Thread.sleep(7000);
 	 
 	 //Select the legal review checkbox
 	 driver.findElement(By.cssSelector(Testelements.Restrictedwordscheckbox_ProductInreview)).click();
 	 
 	 Thread.sleep(2000);
 	 
 	 //Enter the cooments for legal review section
 	 driver.findElement(By.cssSelector(Testelements.Legalreview_Comments)).sendKeys("Set to Restricted words Review");
 	 
 	 Thread.sleep(3000);
 	 
 	
 	 
 	 
 	 //Press the outer area to make the button enable for set to review
 	 driver.findElement(By.cssSelector(Testelements.legalreview_Clickbalearea_ButtonEnable)).click();
 	 
 	 Thread.sleep(4000);
 	 
 	 //Press the set to review button for legal
 	 driver.findElement(By.cssSelector(Testelements.SelectedProductInreview_Button)).click();
 	 
 	 Thread.sleep(6000);
 	 
 	 //Press the ok to confirm email
 	 driver.findElement(By.cssSelector(Testelements.EmailNotificationalert_Confirm)).click();
 	 
 	 Thread.sleep(2000);
 	 
 	 driver.navigate().refresh();
 	 
 	 wait = new WebDriverWait(driver, 120);
 	 wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.ProductRestrictedwordstext)));
 	 
 	 if(driver.findElement(By.cssSelector(Testelements.ProductRestrictedwordstext)).getText().equals("Your product is in review because of Restricted words")){
 		 
 	       System.out.print("Product becomes inactive sucessfully and changes to restricted words review");
 	       test = extent.startTest("Product_WithRestrictedWords");
 		  	Assert.assertFalse(false);
 		  	test.log(LogStatus.PASS, "Product becomes inactive sucessfully and changes to restricted words review");
 	 
 	 
 	 }
 	 else{
 		 
 		 System.out.print("Product becomes inactive unsucessfull and changes to restricted words review is also unsucessfull");
 	       test = extent.startTest("Product_WithRestrictedWords");
 		  	Assert.assertFalse(false);
 		  	test.log(LogStatus.FAIL, "Product becomes inactive unsucessfull and changes to restricted words review is also unsucessfull");
 	 }
 	 
      Thread.sleep(2000);
  

  }
  
  
  @Test(priority=10)
  public void SupplierInReview_RestrictedWordsReviewProduct_Download() throws InterruptedException{
 	 try{
 	 //Press the EIT Dashboard from action bar
 	 driver.findElement(By.xpath(Testelements.EITDashboardButton)).click();
 	 
 	 //Wait for the EIt Reports tab to appear
 	 //Wait for supplier selection option to appear
      wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITReports_Tab)));
      
      Thread.sleep(3000);
      
      //PRess the EIT Admin tab
      driver.findElement(By.xpath(Testelements.EITReports_Tab)).click();
      
      //Wait for supplier selection option to appear
      wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITReports_Selectreport_dropdown)));
      
      Thread.sleep(3000);
      
  	WebElement mySelectElement20 = driver.findElement(By.xpath(Testelements.EITReports_Selectreport_dropdown));
     Select dropdown20= new Select(mySelectElement20);
    
     dropdown20.selectByVisibleText("Products in review by supplier");
     
     Thread.sleep(3000);
     
     //Select the supplier checkbox
     driver.findElement(By.xpath(Testelements.EITReports_ProductsinReview3)).click();
     
     Thread.sleep(3000);
     
     driver.findElement(By.xpath(Testelements.Restrictedwordscheckbox_SupplierInreview)).click();
     
     Thread.sleep(5000);
     
     driver.findElement(By.xpath(Testelements.EITReports_Download3)).click();
     
     Thread.sleep(15000);
     
     test = extent.startTest("SupplierInReview_RestrictedWordsReviewProduct_Download");
   	Assert.assertFalse(false);
   	test.log(LogStatus.PASS, "Supplier Product with Restricted Words Review downloaded sucessfully");
      
     
  }
  
  catch(NoSuchElementException e){
 	  e.getStackTrace();
 	} 
   
 }
  
 @Test(priority=11)
 public void EITAdmin_Restrictedwords_Sanity() throws InterruptedException{
	 try{
	//Press the EIT Admin Tab
     driver.findElement(By.xpath(Testelements.EITAdminTab)).click();
     
     //Wait for global list tab to be appear
     
 	wait = new WebDriverWait(driver, 180);
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.GlobalListsTab)));
     
     Thread.sleep(2000);
     
     //Press the global lists tab
     driver.findElement(By.xpath(Testelements.GlobalListsTab)).click();
     
     Thread.sleep(8000);
     
     //Select the global list options
     WebElement mySelectElement = driver.findElement(By.xpath(Testelements.GlobalListOperation_Dropdown));
     Select dropdown= new Select(mySelectElement);
    
     dropdown.selectByVisibleText("Manage Restricted words");
     
     
     
     //Wait for Add Restricted words  Button
     wait = new WebDriverWait(driver, 180);
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.AddRestrictedWords_Button)));
     
     Thread.sleep(6000);
     
     //Press the Add Restricted words button
     driver.findElement(By.xpath(Testelements.AddRestrictedWords_Button)).click();
     
     Thread.sleep(4000);
     
     
     //Enter the Trade Name
     driver.findElement(By.xpath(Testelements.RestrictedWordsInsertion_Field)).sendKeys(Testdata.RestrictedWordsAdd);
     
     Thread.sleep(3000);
     
     //Press the Add Trade button in popup
     driver.findElement(By.xpath(Testelements.RestrictedWordsAdd_ButtonPopup)).click();
     
     Thread.sleep(15000);
     
     test = extent.startTest("Add RestrictedWords");
		Assert.assertFalse(false);
		test.log(LogStatus.PASS, "RestrictedWords Added Successfully");
 
		//Search the term
    	driver.findElement(By.xpath(Testelements.RestrictedWordsSearch_Insertion)).sendKeys("Automation");
    	
    	Thread.sleep(2000);
    	
    	//Press the search button
    	driver.findElement(By.xpath(Testelements.RestrictedWordsSearch_Button)).click();
    	
    	Thread.sleep(15000);
    	
    	test = extent.startTest("Search RestrictedWords");
 		Assert.assertFalse(false);
 		test.log(LogStatus.PASS, "RestrictedWords Searched Successfully");
 		
 		//Press the edit button
 	   driver.findElement(By.xpath(Testelements.RestrictedWordsUpdate_Button)).click();
 	   
 	   Thread.sleep(4000);
 	   
 	   //Clear the previous name
 	   WebElement toClear = driver.findElement(By.xpath(Testelements.RestrictedWordsUpdate_InsertionField));
 	     toClear.sendKeys(Keys.CONTROL + "a");
 	     toClear.sendKeys(Keys.DELETE); 
    
       //Wait
 	     Thread.sleep(2000);
 	     
 	  //Enter Updated Trade Name and save
 	     driver.findElement(By.xpath(Testelements.RestrictedWordsUpdate_InsertionField)).sendKeys(Testdata.RestrictedwordsUpdate);
 	     
 	     Thread.sleep(2000);
 	     
 	  //Press the confirm for the update process to be completed
 	     driver.findElement(By.xpath(Testelements.RestrictedWorsUpdate_ConfirmUpdate)).click();
 	     
 	     Thread.sleep(15000);
    
 	     test = extent.startTest("Edit Restricted Words");
 	 		Assert.assertFalse(false);
 	 		test.log(LogStatus.PASS, "Restricted Words Updated Successfully");
 	 		
 	 //Press the delete Button
 	 		driver.findElement(By.xpath(Testelements.RestrictedwordsDelete_Button)).click();
 	 		
 	 		Thread.sleep(4000);
 	 		
 	 //Press OK to delete the restricted word
 	 		driver.findElement(By.xpath(Testelements.RestrictedWordsDelete_PopupOk)).click();
 	 		
 	 		Thread.sleep(15000);
 	 		
 	 		test = extent.startTest("Delete RestrictedWords");
 	 		Assert.assertFalse(false);
 	 		test.log(LogStatus.PASS, "RestrictedWords Deleted Successfully");
 
 
 
 }
  
  
 catch(NoSuchElementException e){
	  e.getStackTrace();
	} 
  
}
  
@Test(priority=12)
public void EITAdmin_SupplierLevel_Validations() throws InterruptedException{
	try{
	//Press the company Level option on eit manager screen
	driver.findElement(By.xpath(Testelements.EITAdmin_CompanyLevel)).click();
	
	wait = new WebDriverWait(driver, 180);
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITAdmin_CompanyLevel_OperationSelection)));
    
    Thread.sleep(3000);
    
    //Creating a robot instance to select option in 2nd place in dropdown
  	WebElement mySelectElement20 = driver.findElement(By.xpath(Testelements.EITAdmin_CompanyLevel_OperationSelection));
      Select dropdown20= new Select(mySelectElement20);
     
      dropdown20.selectByVisibleText("Enable / Disable Validations");
      
      wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EnableDisableASITextField)));
      
      Thread.sleep(3000);
      
      //Enter the ASI Number
      WebElement AsinoField=driver.findElement(By.xpath(Testelements.EnableDisableASITextField));
      AsinoField.sendKeys("30232");
      
      Thread.sleep(3000);
      
      AsinoField.sendKeys(Keys.ENTER);
      
      Thread.sleep(3000);
      
      //Press the show validation button
      driver.findElement(By.xpath(Testelements.ShowValidationButton)).click();
      
      Thread.sleep(10000);
      
      test = extent.startTest("Validation Listings");
		Assert.assertFalse(false);
		test.log(LogStatus.PASS, "Enable/Disable Validation Listins displayed sucessfully on EIT dashboard");
		
	 //Press the Manage Products Tab
		driver.findElement(By.xpath(Testelements.EITManageProducts)).click();
		
		//Wait for supplier asi insertion field to appear
		  wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Supplier_asi_Insertion)));
	      //Send info into asi field
	      driver.findElement(By.cssSelector(Testelements.Supplier_asi_Insertion)).sendKeys("30232");
	      //Click the search for supplier serach
	      driver.findElement(By.cssSelector(Testelements.Supplier_asi_search)).click();
	      //Wait for supplier selection option to appear
	      wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Supplier_selection)));
	      //Select the supplier through clicking
	      driver.findElement(By.cssSelector(Testelements.Supplier_selection)).click();
	 
	      //Wait for supplier selection option to appear
	      wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.ManageProducts_Tab)));
	      
	      Thread.sleep(4000);
	      
	      //Click the manage products tab
	      driver.findElement(By.xpath(Testelements.ManageProducts_Tab)).click();
	      
	      wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.MakeChangesActive)));

	      Thread.sleep(3000);
	      
	      driver.findElement(By.cssSelector(Testelements.MakeChangesActive)).click();
	      
	      wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.MakeChangesActive_Confirm)));
	      
	      Thread.sleep(2000);
	      
	      //Press the ok button to active the product
	      driver.findElement(By.cssSelector(Testelements.MakeChangesActive_Confirm)).click();
	      
	      Thread.sleep(10000);
      
	      wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.EditProduct)));
	      
	      Thread.sleep(4000);
	      
	      driver.findElement(By.cssSelector(Testelements.EditProduct)).click();
	      
	      Thread.sleep(40000);
	      
	      //Goto imprinting tab and select imprinting
	      driver.findElement(By.xpath(Testelements.ImprintingTab)).click();
	      
	      Thread.sleep(18000);
	      
	    //Scroll Up
		    JavascriptExecutor jse = (JavascriptExecutor)driver;
		    jse.executeScript("window.scrollBy(0,250)", "");
		    
		    Thread.sleep(3000);
		    
	   //Check the rush service checkbox
		   driver.findElement(By.cssSelector(Testelements.RushServiceCheckbox)).click();
		   
		   Thread.sleep(3000);
		   
		   driver.findElement(By.cssSelector(Testelements.RushServiceDetailsTextfield)).sendKeys("Asiqa");
		   
		   Thread.sleep(3000);
		   
		   //Manane product listing
		      driver.findElement(By.cssSelector(Testelements.Product_Manage)).click();
		  	 
		      wait = new WebDriverWait(driver, 180);
		      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.MakeChangesActive)));
		     
		      
		  	Thread.sleep(7000);
		  	
		     
		    //Make chnages Active
		    driver.findElement(By.cssSelector(Testelements.MakeChangesActive)).click();
		    
		    Thread.sleep(10000);
		    
		    if(driver.findElement(By.cssSelector(Testelements.ImprintValidationError)).getText().equals("Imprinting: Rush Service Details contains an exact match of Line name:Asiqa")){
		    	
		    	 test = extent.startTest("Validation Message Verification");
		 		Assert.assertFalse(false);
		 		test.log(LogStatus.PASS, "Validation message displaying sucessfully that Imprinting: Rush Service Details contains an exact match of Line name:Asiqa");
		    
		    
		    
		    }
		  	   
		    else{
		    	
		    	 test = extent.startTest("Validation Message Verification ");
			 		Assert.assertFalse(false);
			 		test.log(LogStatus.FAIL, "Validation message displaying unsucessfully that Imprinting: Rush Service Details contains an exact match of Line name:Asiqa");
		    }
	}	
		    catch(NoSuchElementException e){
		  	  e.getStackTrace();
		  	} 
	      
	      
}
	

 
 @Test(priority=13)
 public void ScoreCard_EmailFrequency() throws InterruptedException{
	 try{
	 //Press the cancel button from error validation message
	driver.findElement(By.cssSelector(Testelements.CancelValidationErrorMessage)).click();
	 
	 Thread.sleep(4000);
	 
	 //Goto ScoreCard Screen
	 driver.findElement(By.cssSelector(Testelements.ScorecardTab)).click();
	 
	 Thread.sleep(30000);
	 
	 //Go to the bottom of page
	 Actions actions = new Actions(driver);
 	 actions.sendKeys(Keys.END).perform();
 	 
 	 //Scroll Up
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("window.scrollBy(0,-150)", "");
	    
	    Thread.sleep(3000);
 	 
 	 Thread.sleep(4000);
 	 
 	 //Press the change frequency button
 	 WebElement Changebutton=driver.findElement(By.xpath(Testelements.EmailFrequencyChangeButton));
 	 //For Quarterly Frequency
 	 Changebutton.click();
 	 
 	 
 	 
 	WebElement mySelectElement20 = driver.findElement(By.cssSelector(Testelements.Frequency_Dropdown));
    Select dropdown20= new Select(mySelectElement20);
   
    dropdown20.selectByVisibleText("Quarterly");
    
    WebElement SaveChangesButton=driver.findElement(By.cssSelector(Testelements.Frequency_SaveChanges_Button));
    
    //Press the save changes button
    SaveChangesButton.click();
    
    Thread.sleep(6000);
    
    if(driver.findElement(By.cssSelector(Testelements.FrequencyValidationcheck)).getText().equals("Quarterly"))
    {
    	
    	 test = extent.startTest("Frequency Status changes to Quarterly on Scorecard");
	 		Assert.assertFalse(false);
	 		test.log(LogStatus.PASS, "Frequency Status changes to Quarterly Sucessfully on Scorecard");
    
    
    }
    else{
    	
    	test = extent.startTest("Frequency Status changes to Quarterly on Scorecard");
 		Assert.assertFalse(false);
 		test.log(LogStatus.PASS, "Frequency Status changes to Quarterly Unsucessfull on Scorecard");

    }
    
    
    
    Changebutton.click();
	 
	 
	 //For Monthly Frequency
 	WebElement mySelectElement21 = driver.findElement(By.cssSelector(Testelements.Frequency_Dropdown));
    Select dropdown21= new Select(mySelectElement21);
   
    dropdown21.selectByVisibleText("Monthly");
    
    SaveChangesButton.click();
    
    Thread.sleep(6000);
    
    if(driver.findElement(By.cssSelector(Testelements.FrequencyValidationcheck)).getText().equals("Monthly"))
    {
    	
    	 test = extent.startTest("Frequency Status changes to Monthly on Scorecard");
	 		Assert.assertFalse(false);
	 		test.log(LogStatus.PASS, "Frequency Status changes to Monthly Sucessfully on Scorecard");
    
    
    }
    else{
    	
    	test = extent.startTest("Frequency Status changes to Monthly on Scorecard");
 		Assert.assertFalse(false);
 		test.log(LogStatus.PASS, "Frequency Status changes to Monthly Unsucessfull on Scorecard");

    }
    
    
    
    Changebutton.click();
	 
	 
	 //For Biannual frequency
 	WebElement mySelectElement22 = driver.findElement(By.cssSelector(Testelements.Frequency_Dropdown));
    Select dropdown22= new Select(mySelectElement22);
   
    dropdown22.selectByVisibleText("Biannually");
    
    SaveChangesButton.click();
    
    Thread.sleep(6000);
    
   
    if(driver.findElement(By.cssSelector(Testelements.FrequencyValidationcheck)).getText().equals("Biannually"))
    {
    	
    	 test = extent.startTest("Frequency Status changes to Biannually on Scorecard");
	 		Assert.assertFalse(false);
	 		test.log(LogStatus.PASS, "Frequency Status changes to Biannually Sucessfully on Scorecard");
    
    
    }
    else{
    	
    	test = extent.startTest("Frequency Status changes to Biannually on Scorecard ");
 		Assert.assertFalse(false);
 		test.log(LogStatus.PASS, "Frequency Status changes to Biannually Unsucessfull on Scorecard");

    }
    
    
    
    
    
    Changebutton.click();
	 
	 //For Never Frequency
	 
 	WebElement mySelectElement23 = driver.findElement(By.cssSelector(Testelements.Frequency_Dropdown));
    Select dropdown23= new Select(mySelectElement23);
   
    dropdown23.selectByVisibleText("Never");
    
    SaveChangesButton.click();
    
    Thread.sleep(6000);
    
    if(driver.findElement(By.cssSelector(Testelements.FrequencyValidationcheck)).getText().equals("Never"))
    {
    	
    	 test = extent.startTest("Frequency Status changes to Never on Scorecard");
	 		Assert.assertFalse(false);
	 		test.log(LogStatus.PASS, "Frequency Status changes to Never Sucessfully on Scorecard");
    
    
    }
    else{
    	
    	test = extent.startTest("Frequency Status changes to Never on Scorecard");
 		Assert.assertFalse(false);
 		test.log(LogStatus.PASS, "Frequency Status changes to Never Unsucessfull on Scorecard");

    }
	 }
	 catch(NoSuchElementException e){
		  e.getStackTrace();
		} 
 
 
 }
 
 @Test(priority=14)
 public void EITAdmin_EmailFrequency_WithScorecardEmailFrequencyChanges() throws InterruptedException{
	 try{
	 //Goto EIt Manager tab
	 driver.findElement(By.xpath(Testelements.EITManager_Tab)).click();
	 
	  wait = new WebDriverWait(driver, 180);
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITAdmin_Tab)));
     
      
  	Thread.sleep(2000);
	 
	 
	 
	 //Wait for the EIT Comapny level to appear tab to be appear
	 driver.findElement(By.xpath(Testelements.EITAdmin_Tab)).click();
	 
	 wait = new WebDriverWait(driver, 180);
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITAdmin_CompanyLevel)));
    
     
 	Thread.sleep(2000);
 	
 	driver.findElement(By.xpath(Testelements.EITAdmin_CompanyLevel)).click();
 	
 	 wait = new WebDriverWait(driver, 180);
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITAdmin_CompanyLevel_OperationSelection)));
     
     Thread.sleep(2000);
     
     WebElement mySelectElement20 = driver.findElement(By.xpath(Testelements.EITAdmin_CompanyLevel_OperationSelection));
     Select dropdown20= new Select(mySelectElement20);
    
     dropdown20.selectByVisibleText("Set Product Scorecard Email Frequency");
    
     wait = new WebDriverWait(driver, 180);
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.CustomerASI_Field)));
     
     Thread.sleep(2000);
     
     //Enter the asino in the select customer field
     driver.findElement(By.xpath(Testelements.CustomerASI_Field)).sendKeys("30232");
     
     Thread.sleep(2000);
     
     driver.findElement(By.xpath(Testelements.CustomerASI_Field)).sendKeys(Keys.ENTER);
     
     Thread.sleep(20000);
     
     if(driver.getCurrentUrl().contains("uat")){
     //Search which is being assigned the eit manager licence
     driver.findElement(By.xpath(Testelements.SearchCustomerUser)).sendKeys("faheem");
     
     Thread.sleep(3000);
     
     //Press the search button
     driver.findElement(By.xpath(Testelements.SearchCustomerUser_ButtonSearch)).click();
     
     wait = new WebDriverWait(driver, 180);
     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITAdmin_EmailFrequency_Biannualy_UAT_Prod)));
     
     Thread.sleep(2000);
 
     //Press the biannuall radio button
     driver.findElement(By.xpath(Testelements.EITAdmin_EmailFrequency_Biannualy_UAT_Prod)).click();
     
     Thread.sleep(12000);
     }
     else{
    	 
    	 //Search which is being assigned the eit manager licence
         driver.findElement(By.xpath(Testelements.SearchCustomerUser)).sendKeys("bilal mubarik");
         
         Thread.sleep(3000);
         
         //Press the search button
         driver.findElement(By.xpath(Testelements.SearchCustomerUser_ButtonSearch)).click();
         
         wait = new WebDriverWait(driver, 180);
         wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.EITAdmin_EmailFrequency_Biannualy_Stage)));
         
         Thread.sleep(2000);
     
         //Press the biannuall radio button
         driver.findElement(By.cssSelector(Testelements.EITAdmin_EmailFrequency_Biannualy_Stage)).click();
         
         Thread.sleep(12000);
     
     
     }
     
     //Now verify on Scorecard screen email frequency area the email frequency changes to binannually
     
     //Scroll Up
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("window.scrollBy(0,-250)", "");
	    
	    Thread.sleep(3000);
	    
	 //Press the manage products tab
	    driver.findElement(By.xpath(Testelements.EITManageProducts)).click();
	    
	    //Wait for supplier asi insertion field to appear
		  wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Supplier_asi_Insertion)));
	      //Send info into asi field
	      driver.findElement(By.cssSelector(Testelements.Supplier_asi_Insertion)).sendKeys("30232");
	      //Click the search for supplier serach
	      driver.findElement(By.cssSelector(Testelements.Supplier_asi_search)).click();
	      //Wait for supplier selection option to appear
	      wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.Supplier_selection)));
	      //Select the supplier through clicking
	      driver.findElement(By.cssSelector(Testelements.Supplier_selection)).click(); 
	      
	      wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.ProductScorecardText)));
	      
	      Thread.sleep(4000);
	      
	    //Go to the bottom of page
	 	 Actions actions = new Actions(driver);
	  	 actions.sendKeys(Keys.END).perform();
	  	 
	  	 //Scroll Up
		    JavascriptExecutor jse78 = (JavascriptExecutor)driver;
		    jse78.executeScript("window.scrollBy(0,-150)", "");
	  	   
		    Thread.sleep(3000);
		
	  	  if(driver.findElement(By.cssSelector(Testelements.FrequencyValidationcheck)).getText().equals("Biannually"))
	      {
	      	
	      	 test = extent.startTest("Frequency Status changes taking effect when changes form EIT Admin to Biannually on Scorecard");
	  	 		Assert.assertFalse(false);
	  	 		test.log(LogStatus.PASS, "Frequency Status changes taking effect when changes form EIT Admin to Biannually on Scorecard");
	      
	      
	      }
	      else{
	      	
	      	test = extent.startTest("Frequency Status changes taking effect when changes form EIT Admin to Biannually on Scorecard ");
	   		Assert.assertFalse(false);
	   		test.log(LogStatus.PASS, "Frequency Status changes taking effect when changes form EIT Admin to Biannually Unsucessfull on Scorecard");

	      }
	  	  
	  	  Thread.sleep(3000);
	 }
	 catch(NoSuchElementException e){
		  e.getStackTrace();
		} 
 
 }
 
 @Test(priority=15)
 public void ScorecardChanges() throws InterruptedException{
	 try{
	 //Scroll to the top
	//Scroll Up
	    JavascriptExecutor jse78 = (JavascriptExecutor)driver;
	    jse78.executeScript("window.scrollBy(0,-250)", "");
	    
	    JavascriptExecutor jse79 = (JavascriptExecutor)driver;
	    jse79.executeScript("window.scrollBy(-250,-500)", "");
	 
        Thread.sleep(3000);
	    //Verify the text change fro discovery to Search
	    if(driver.findElement(By.xpath(Testelements.SearchText_Scorecard)).getText().equals("Search")){
	    	
	    	System.out.print("Search Heading display sucessfully");
	    	test = extent.startTest("Search Heading On ScoreCard");
  	 		Assert.assertFalse(false);
  	 		test.log(LogStatus.PASS, "Search Heading On ScoreCard Sucessfully");
      
	    }
 
	    else{
	    	
	    	System.out.print("Search Heading display Unsucessfully");
	    	test = extent.startTest("Search Heading On ScoreCard");
  	 		Assert.assertFalse(false);
  	 		test.log(LogStatus.FAIL, "Search Heading On ScoreCard  Unsucessfully");
	    }
 
     //Verify the (s) in products text 
	    if(driver.findElement(By.xpath(Testelements.SearchAreaWithS_Inbetween)).getText().contains("(s)"))
	    		{
	    	
	    	System.out.print("Product contains (s) in viw like product(s) sucessfully");
	    	test = extent.startTest("Text changes on Scorecard");
  	 		Assert.assertFalse(false);
  	 		test.log(LogStatus.PASS, "Product contains (s) in viw like product(s) Sucessfully");
      
	    	   
	    		}
	    else{
	    	
	    	System.out.print("Product contains (s) in viw like product(s) unsucessfully");
	    	test = extent.startTest("Text changes on Scorecard");
  	 		Assert.assertFalse(false);
  	 		test.log(LogStatus.FAIL, "Product contains (s) in viw like product(s) unsucessfully");
      
	    }

	  //Scroll Up
	    JavascriptExecutor jse80 = (JavascriptExecutor)driver;
	    jse80.executeScript("window.scrollBy(0,250)", "");
	    
	    
	    if(driver.findElement(By.cssSelector(Testelements.ScorecardDisplaying_WhileScrolling)).isDisplayed()){
	    	
	    	System.out.print("Scorecard Summary displayed sucessfully after scrolling");
	    	test = extent.startTest("Scorecard Summary Displayed While Scrolling");
  	 		Assert.assertFalse(false);
  	 		test.log(LogStatus.PASS, "Scorecard Summary displayed sucessfully after scrolling Sucessfully");
      	
	    }
 
	    else{
	    	System.out.print("Scorecard Summary displayed sucessfully after scrolling");
	    	test = extent.startTest("Text changes on Scorecard");
  	 		Assert.assertFalse(false);
  	 		test.log(LogStatus.FAIL, "Product contains (s) in viw like product(s) unsucessfully");
      
	    	
	    }
 
	 }
	 catch(NoSuchElementException e){
		  e.getStackTrace();
		} 
 }

 @Test(priority=16)
 public void SentEmail_ToSuppliers() throws InterruptedException{
	try{
	 
	      driver.findElement(By.xpath(Testelements.EITManager_Tab)).click();
		 
		  wait = new WebDriverWait(driver, 180);
	      wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITAdmin_Tab)));
	     
	      
	  	Thread.sleep(2000);
		 
		 
		 
		 //Wait for the EIT Comapny level to appear tab to be appear
		 driver.findElement(By.xpath(Testelements.EITAdmin_Tab)).click();
		 
		 wait = new WebDriverWait(driver, 180);
	     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITAdmin_CompanyLevel)));
	    
	     
	 	Thread.sleep(2000);
	 	
	 	driver.findElement(By.xpath(Testelements.EITAdmin_CompanyLevel)).click();
	 	
	 	 wait = new WebDriverWait(driver, 180);
	     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.EITAdmin_CompanyLevel_OperationSelection)));
	     
	     Thread.sleep(2000);
	     
	     WebElement mySelectElement20 = driver.findElement(By.xpath(Testelements.EITAdmin_CompanyLevel_OperationSelection));
	     Select dropdown20= new Select(mySelectElement20);
	    
	     dropdown20.selectByVisibleText("Set Product Scorecard Email Frequency");
	    
	     wait = new WebDriverWait(driver, 180);
	     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.CustomerASI_Field)));
	     
	     Thread.sleep(2000);
	     
	     //Enter the asino in the select customer field
	     driver.findElement(By.xpath(Testelements.CustomerASI_Field)).sendKeys("30232");
	     
	     Thread.sleep(2000);
	     
	     driver.findElement(By.xpath(Testelements.CustomerASI_Field)).sendKeys(Keys.ENTER);
	     
	     Thread.sleep(20000);
	     
	     //Search which is being assigned the eit manager licence
	     driver.findElement(By.xpath(Testelements.SearchCustomerUser)).sendKeys("bilal Mubarik");
	     
	     Thread.sleep(3000);
	     
	     //Press the search button
	     driver.findElement(By.xpath(Testelements.SearchCustomerUser_ButtonSearch)).click();
	     
	     if(driver.getCurrentUrl().contains("stage")){
	    	 
	    	 wait = new WebDriverWait(driver, 180);
		     wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Testelements.SendEmail_ToSupplier_Stage)));
		     
		     Thread.sleep(3000);
		     
		     //Press the email button to send the email to supplier
		     driver.findElement(By.cssSelector(Testelements.SendEmail_ToSupplier_Stage)).click();
		     
		     Thread.sleep(5000);
	     }
	     else{
	     wait = new WebDriverWait(driver, 180);
	     wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Testelements.SendEmail_ToSupplier_Button_UAT_Prod)));
	     
	     Thread.sleep(3000);
	     
	     //Press the email button to send the email to supplier
	     driver.findElement(By.xpath(Testelements.SendEmail_ToSupplier_Button_UAT_Prod)).click();
	     
	     Thread.sleep(5000);
	     }
	     
	  // Switching to Alert        
	        Alert alert = driver.switchTo().alert();		
	        		
	        // Capturing alert message.    
	        String alertMessage= driver.switchTo().alert().getText();		
	        		
	        // Displaying alert message		
	        System.out.println(alertMessage);	
	        Thread.sleep(5000);
	        		
	        // Accepting alert		
	        alert.accept();	
	        
	        
	        Thread.sleep(15000);
	        
	     // Switching to Alert        
	        Alert alertConfirm = driver.switchTo().alert();		
	        		
	        // Capturing alert message.    
	        String alertMessageConfirm= driver.switchTo().alert().getText();		
	        		
	        // Displaying alert message		
	        System.out.println(alertMessageConfirm);	
	        Thread.sleep(5000);
	        		
	        // Accepting alert		
	        alertConfirm.accept();	
	        
	        Thread.sleep(5000);
	        
	        System.out.print("ScoreCard Email Sent to supplier sucessfully");
	    	test = extent.startTest("SentScoreCardEmail_ToSuppliers");
  	 		Assert.assertFalse(false);
  	 		test.log(LogStatus.PASS, "ScoreCard Email Sent to supplier sucessfully");
      	
 }
 catch(NoSuchElementException e){
	  e.getStackTrace();
	} 
	 
 }
 
 
 
 
 
 
 
 
 
 
 @AfterMethod
  public void getResult(ITestResult result){
  	
  	if(result.getStatus()==ITestResult.FAILURE){
  		
  		test.log(LogStatus.FAIL, result.getThrowable());
  	}
  	
  	extent.endTest(test);
  }

   
   
   
   
   
   @AfterTest
  public void teardown(){
   	extent.flush();
   	
   	driver.close();
   	
  }




}

